import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'directives-ang';

  myNumb:number=80;
  hide:boolean=false;

  myStyle={'background-color':'green',color:'red'}

  prod:Product[]=[
		{prodId:1001,prodName:'tv',desc:'sample',qty:8,price:9898},
    {prodId:1002,prodName:'ac',desc:'data',qty:4,price:8900},
    {prodId:1003,prodName:'watch',desc:'data sample',qty:2,price:3900},
    {prodId:1004,prodName:'stove',desc:'sample new data',qty:6,price:9001},
		{prodId:1005,prodName:'mobile',desc:'a-sample',qty:8,price:30898}
];

frac:number=2.5678946456;

today:Date=new Date();

mymoney=9678.45366363;
}

class Product{
 
  prodId: number;
  prodName:string ;
  desc:string;
  qty:number;
  price:number;
}
