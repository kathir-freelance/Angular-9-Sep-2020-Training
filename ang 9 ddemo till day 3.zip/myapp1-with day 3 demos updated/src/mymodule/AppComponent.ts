import { Component } from "@angular/core";

@Component({
    selector: 'app-data',
    template:`<h1> hi hello {{name}}</h1>
                <input type='text' [value]=name #data />
                <input type='text' [disabled]=status #t2 (input)="getAndSetName(t2.value)"/>
                <input type='text' (input)='onEvent($event)'/>
                <button (click)="getAndSetName(data.value)">Get & Set</button>
                <button (click)="changeStatus()">click</button>

                  <h1> two way binding</h1>

                  city : <input type='text' [(ngModel)]="city"/>
                    {{city}}
                `
})
export class AppComponent{

  city:string;
    name:string='Aj'
    status:boolean=false;
    changeStatus=()=>{
        console.log('hi');
      this.status= this.status===true?false:true; //assigning the toggled valued
      //this.status=!this.status;
    }
onEvent=(event:any)=>{
  alert(event.target.value);
}
    getAndSetName=(name:string)=>{
        alert(name);
          this.name=name;
    }
}