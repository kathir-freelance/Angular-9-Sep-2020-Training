import { NgModule } from "@angular/core";
import {AppComponent} from './AppComponent'
import {BrowserModule} from '@angular/platform-browser'

@NgModule({

    declarations:[AppComponent],
    bootstrap:[AppComponent],    
    imports:[BrowserModule]
})
export class MyModule{

}