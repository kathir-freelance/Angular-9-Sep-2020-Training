import { Component } from "@angular/core";

@Component({
    selector: 'app-data',
    template:`<h1> hi hello {{name}}</h1>
                <input type='text' [value]=name/>
                <input type='text' [disabled]=status/>
                <button (click)="changeStatus()">click</button>
                `
})
export class AppComponent{

    name:string='Aj'
    status:boolean=false;
    changeStatus=()=>{
        console.log('hi');
      this.status= this.status===true?false:true; //assigning the toggled valued
      //this.status=!this.status;
    }

}